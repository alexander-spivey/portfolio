# CSE 109 - Quiz 1

**Due: 2/9/2021 End of Day**

Make at least one commit per question. You can write your answers in this file, README.md file. You can use the Gitlab interface to edit this file if you prefer.

## Question 1

What is a version control system? Why are they useful? What is git? What is gitlab?
Version control systems help code teams manage changes to their code and which iterations. Allowing them to only change one file at a time, not disturbing others. Git is software made for tracking chantges and coordinating with others. Gitlab is where we do our work. Basically the best of git and github merged into one application. 

## Question 2

What does it mean when we say Git is a *distributed* version control system? What is being distributed?
Its a system made for pulling information from one repository to another through series of push and pulls, commits and updates. The updates are whast is being distrubited. 

## Question 3

What do the following commands do?

- git add: add files to commit
- git pull: pull files from repository
- git commit: files commented with updates ready to be pushed out
- git push: push updates to repositoy to overwrite current state
