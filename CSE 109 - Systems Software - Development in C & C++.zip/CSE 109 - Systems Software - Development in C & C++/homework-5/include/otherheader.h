// This function subtracts two integers
int sub(int x, int y);