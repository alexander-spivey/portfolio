#include <otherheader.h>

// Add two integers
int add(int x, int y);