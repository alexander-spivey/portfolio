// Add two integers
int add(int x, int y) {
  return x + y;
}