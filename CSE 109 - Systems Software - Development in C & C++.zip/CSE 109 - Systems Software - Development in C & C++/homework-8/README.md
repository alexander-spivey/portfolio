# CSE 109 - Homework 8

**Due Date: 4/23/2021 EOD**

## Instructions

**Read thoroughly before starting your project:**

1. Fork this repository into your CSE109 project namespace. [Instructions](https://docs.gitlab.com/ee/workflow/forking_workflow.html#creating-a-fork)
2. Clone your newly forked repository onto your development machine. [Instructions](https://docs.gitlab.com/ee/gitlab-basics/start-using-git.html#clone-a-repository) 
3. As you are writing code you should commit patches along the way. *i.e.* don't just submit all your code in one big commit when you're all done. Commit your progress as you work. **You should make at least one commit per function.**
4. When you've committed all of your work, there's nothing left to do to submit the assignment.

## Assignment

This homework assignment is pretty straightforward. You won't have to write a lot of code, because the code is already written for you in in the Week 11 reading. The main purpose of this assignment is to prepare you for Homework 9, which will be the last homework assignment before the Final Exam. Homework 9 will integrate many of the topics we've covered throughout the course into one assignment, so I want to make sure you have a basic grasp on Unix Sockets before we try something harder.

All instructions in this assignment related to the Week 11 reading found [here](https://www.tutorialspoint.com/unix_sockets/socket_quick_guide.htm). You will be writing this assignment in C, so you'll be using the `gcc` compiler again instead of `g++`.

## Part 1 - Client

Copy the client code from the Unix Socket Tutorial into a file called `src/bin/client.c`. Write a Makefile in the project root with the following directives:

- `client` - builds the `client.c` source code into an executable called `client` and places it in `build/bin/release`
- `clean` - removes the `build` directory and all contents

### Explanation

***WITH COREY'S PERMISSION, I DONT HAVE TO RECORD SINCE I AM WORKING ON LIMITED DATA. INSTEAD I COULD JUST EXPLAIN***

- `sockfd = socket(AF_INET, SOCK_STREAM, 0);` 
//This one is actually fairly simple. So to call the function socket you need the following: domain (comm domain such as AF_INET or AF_UNIX), type (stream socket (reliable cuz has connection), datagram (unreliable cause no connection), or one of the other two that no one ever uses), and protocal (which is 0, protocal value for IP). This command creates a socket with the name sockfd, which will act as a socket descriptor (a file-handle). If success, a file descriptor is returned, else -1 for error.
- `connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr))`
//This is the connect command, with connects the sockfd (file descriptor) to the address (serv_addr) with the size of the current serv_addr. Serv_addr holds the address and port. If bind/connect works, return 0, else -1 for error. 
- `fgets(buffer,255,stdin);`
//Fgets reads a line from string/char (buffer) at line 255 and stores it to the string pointed to by buffer. Stdin is a pointer to a file where the characters are read from. If successful, it will return the same string parameter, if not, a null pointer is returned. 
- `n = write(sockfd, buffer, strlen(buffer));`
//The write command will try to write a number of (strlen(buffer)) bytes from the buffer to the file that is associated with the file descriptor (sockfd). On succes, the number of bytes written is returned and -1 is error. 
- `n = read(sockfd, buffer, 255);`
//Read from a file decriptor (sockfd) up to 255 bytes into the buffer. If it return zero, no errors, -1, if error. 

Explain the purpose of these functions, what the input arguments mean, and what the return values indicate. Also explain their context in the larger client program.
## Part 2 - Server

Copy the single connection server code from the Unix Socket Tutorial into a file called `src/bin/server.c`. Modify your Makefile to include the following directive:

- `server` - builds the `server.c` source code into an executable called `server` and places it in `build/bin/release`

### Explanation

Record another video that explains the server program to me. In particular, explain the following lines of code:

- `sockfd = socket(AF_INET, SOCK_STREAM, 0);`
//Create a socket with domain AF_INET, and type sock_stream (cuz it is reliable connection), and 0 is the protocal value for IP. If success, a file descriptor is returned, else -1 for error. 
- `bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)`
//Bind binds an adress to socket since when they are first made, they have no adress assigned. Sizeof(serv_addr) specifies the size of the address in bytes. Known as "assigning a name to a socket." If bind/connect works, return 0, else -1 for error.
- `listen(sockfd,5);`
//Listen marks the socket (sockfd) as a passive (recieving incoming connections) socket. The number (5) is the number of allowed queue of pending connectiuons allowed at one point. If succes, return 0, else -1. 
- `newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);`
//Accept grabs the first connection request from queue and creates a new connected socket with the client address and with lenght of clilen. If success, a file descriptor is returned, else -1 for error. 
- `n = read( newsockfd,buffer,255 );`
//Read from a file decriptor (newsockfd) up to 255 bytes into the called string (buffer). If it return zero, no errors, -1, if error. 
- `n = write(newsockfd,"I got your message",18);`
//The write command will try to write "I got your message" to the file descriptor (newsockfd) up to 18 bytes. On succes, the number of bytes written is returned and -1 is error. 

Explain the purpose of these functions, what the input arguments mean, and what the return values indicate. Also explain their context in the larger server program.
## Part 3 - Demonstration

Record one final video demonstrating the client and server communicating with eachother. Build your client and server programs with your Makefile. You'll want to open two different terminals to demonstrate the programs communicating. In one terminal, start up the server on a port (5001 is the one used in the source, but it does't really matter. If this is being used on your computer, choose a different one). In a second terminal, start your client program and have it connect to your server. Make sure the client and server programs are arranged side-by-side, so you can see the messages in both terminatls. The client terminal will prompt you to enter a message. You can enter anything you like, and you should see your message arrive at the server terminal with the message `"Here is the message:"`. The server will send back the message `"I got your message"` to the client, and you should see that appear in the client window.

`I included the demonstration as: `
    ![Proof Of Demo](ProofOfDemo.png)
