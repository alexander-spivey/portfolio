# CSE 109 - Quiz 2

**Due: 2/16/2021 End of Day**

Make at least one commit per question. You can write your answers in this file, `README.md`. You can use the Gitlab interface to edit this file if you prefer.

## Question 1

What are the four tenents of the Unix Philosophy? Give an example of each tenent in practice.

Make each program do one thing well. Calculate only tax
Build a prototype as soon as possible. Get idea on paper, pseudocode for homework-2, learn as you do
Choose portability over efficiency. 
Store data in flat text files. CSE-017 java programs would use basic text files to help input a bunch of data and variables at once with a Scanner


## Question 2

What is the purpose of a library, and why would we want to write code in a library rather than just writing all of our code in one `main.c` file? Give two reasons.

The reason to have a libvrary is to keep all the extra functions out of main, in doing so it makes the main code easier to read, 
and you can easily find the functions you implemneted and modify with them ease



## Question 3

Consider the Makefile in the [project template](https://gitlab.com/lehigh-cse-109/spring-2021/course-info/-/blob/master/project-template.zip) when answering the following:

- What is a Makefile and why would we want to use one?
- What does the command `gcc src/lib.c -c` do? In particular, what is the role of the `-c` flag in this command?
- What does the command `ar rs -o libmylib.a lib.o` do? What is the output of this command?
- What does the commnad `gcc src/bin/main.c -lmylib -L. -I include` do? In particular:
  - What is the role of the `-l` flag?
  - What is the role of the `-L` flag? What does `-L.` mean?
  - What is the role of the `-I` flag?
	

Makefile easily updates and compiles all files used in your project with one call command
gcc src/lib.c -c: gcc is the compiler called, src/lib.c is the file path and name, and -c calls to generate the object file
ar rs -o libmylib.a lib.o: ar is used to create archive file, rs is add with replace, -o is ouptut, the first file is the base file, the last file is the output file
gcc src/bin/main.c -lmylib -L. -I include: it is calling to compile src/bin/main.c, file path and name, -L defines additional Library paths, -I defines any pathways for any extra header files, and -l will add the listed library into the exe. 

	

