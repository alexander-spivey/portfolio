#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
// Initialize an empty list
/*Node* head = NULL;
	Node* tail = NULL;

	head = new Node(); 
	tail = new Node();
	*head = *list_pointer*/
void initList(List* list) {
	list->head = NULL;
    list->tail = NULL;
}

// Create node containing item, return reference of it.
Node* createNode(void* value) {
	Node* node = malloc(sizeof(Node));
	node->item = value;
	return node;
}

// Insert item at start of the list.
int insertAtHead(List* list, void* item){
	Node* temp = createNode(item); //create new node with the item
	if(temp == NULL) { //if node is null return 1 for failre
		return 1;
	}
	temp->next = list->head; //we say that the temp node is now the head node
	list->head = temp; //and we now add the temp to the list????
	return 0; //return sucess
}

// Insert new item at the end of list.
int insertAtTail(List* list, void* item) {
	Node* temp = createNode(item);//create a new node with item
	if(temp == NULL) { //if node is null return 1 for failre
		return 1;
	}
	temp->next = NULL; //we set the next node after the temp to be null

	Node* pointer; //creating a pointer
	pointer = (Node*) list->head; //TRAVERSING THE LIST
 
	while(pointer->next != NULL) { //while pointer still exists
		pointer = pointer->next;
	}
	//we hit null, time to add temp
	pointer->next = temp; //set next of pointer to be temp
	list->tail = pointer->next; //set tail to be the pointer->next
	return 0; //return sucess
}

// Insert item at a specified index.
int insertAtIndex(List* list, int index, void* item) {
	Node* temp = createNode(item);//create a new node with item
	if(temp == NULL) { //if node is null return 1 for failre
		return 1;
	}
	Node* pointer; //creating a pointer
	pointer = (Node*) list->head; //TRAVERSING THE LIST
 
	for(size_t c = 1; c < index; c++) { //move the pointer to da index
		pointer = pointer->next;
		if(pointer == NULL) { //if it null, means we passed stuff already
			return 1;
		}
	}
	temp->next = pointer->next;//place right immediatly after
	pointer->next = temp;
	return 0; //return sucess
}

// Remove item from the end of list and return a reference to it
void* removeTail(List* list){
	Node* temp; //making our tempest boi
	if(list->head == NULL) { //no head equals nothign to delete or reasons to date
		return;
	} else { //it do give head
		Node* pointer; //our lil pointer boi
		pointer = (Node*) list->head; //setting our pointer to have the same use as our head;
		while(pointer->next != NULL) { //if pointer next is not null dont stop
			pointer = pointer->next;
		} //pointer is now on last actual node
		temp = pointer; //set temp equal to the pointer(aka the last node)
		pointer = temp->next; //set the last node as temp next (which is null)
		int *itemreturned = temp->item; //doing this so we can free temp and use the int to return it
		free(pointer);
		free(temp); //free my boi he did nothing wrong
		return itemreturned; //returned value that was removed :D
	}
}

// Remove item from start of list and return a reference to it
void* removeHead(List* list){
	Node* temp; 
	if(list->head == NULL) { //if head doesn't even exist nothing to delete
		return;
	} else { //there is head to delete ;)
		temp = list->head; //setting temp to head
		list->head = temp->next; //setting head to next temp (which is null cuz only the curent temp has item)
		int *itemreturned = temp->item; //doing this so we can free temp and use the int to return it
		free(temp); //free my boi he did nothing wrong
		return itemreturned; //returned value that was removed :D
	}
}

// Insert item at a specified index and return a reference to it
void* removeAtIndex(List* list, int index){
	Node* temp; //making our tempest boi
	if(list->head == NULL) { //no head equals nothign to delete or reasons to date
		return;
	} else { //it do give head
		Node* pointer; //our lil pointer boi
		pointer = (Node*) list->head; //setting our pointer to have the same use as our head;
		for(size_t c = 0; c < index; c++) { //loop for right index (idk why sometimes 1 or 0 work better xD)
			pointer = pointer->next; //move that thicc pointer over
		} //on the proper index now
		temp = pointer; //set temp equal to the pointer(aka the last node)
		pointer = temp->next; //set the last node as temp next (which is null)
		int *itemreturned = temp->item; //doing this so we can free temp and use the int to return it
		free(pointer);
		free(temp); //free my boi he did nothing wrong
		return itemreturned; //returned value that was removed :D
	}
}

// Return item at index
void* itemAtIndex(List* list, int index) {
	Node* pointer; //creating a pointer
	pointer = (Node*) list->head; //TRAVERSING THE LIST
 
	for(size_t c = 0; c < index; c++) { //move the pointer to da index
		pointer = pointer->next;
		if(pointer == NULL) { //if it null, means we passed stuff already
			return 1;
		}
	}
	return pointer->item;
}

/*void printList(List *list) //THIS IS WINTON WANG'S PRINT STATMENT ( I AM USING IT TO CHECK THE PRINTS)
{
    Node *node;

    // Handle an empty node. Just print a message.
    if (list->head == NULL)
    {
        printf("\nEmpty List");
        return;
    }

    // Start with the head.
    node = (Node *)list->head;

    printf("\nList: \n\n\t");
    while (node != NULL)
    {
        printf("[ %x ]", *(int *)node->item);

        // Move to the next node
        node = (Node *)node->next;

        if (node != NULL)
        {
            printf("-->");
        }
    }
    printf("\n\n");
}*/

void printList(List* list) {
	Node* node;

  	// Handle an empty node. Just print a message.
	if(list->head == NULL) {
		printf("\nEmpty List");
		return;
	}
	
  	// Start with the head. TRAVERSING THE LIST
	node = (Node*) list->head;

	printf("\nList: \n\n\t"); 
	while(node != NULL) {
		printf("[ %x ]", node->item);

		// Move to the next node
		node = (Node*) node->next;

		if(node !=NULL) {
			printf("-->");
		}
	}
	printf("\n\n");
}
