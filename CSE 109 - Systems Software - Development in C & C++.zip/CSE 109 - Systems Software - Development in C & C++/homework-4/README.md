# CSE 109 - Homework 4

**Due Date: 3/3/2021 EOD**

## Instructions 

**Read thoroughly before starting your project:**

1. Fork this repository into your CSE109 project namespace. [Instructions](https://docs.gitlab.com/ee/workflow/forking_workflow.html#creating-a-fork)
2. Clone your newly forked repository onto your development machine. [Instructions](https://docs.gitlab.com/ee/gitlab-basics/start-using-git.html#clone-a-repository) 
3. As you are writing code you should commit patches along the way. *i.e.* don't just submit all your code in one big commit when you're all done. Commit your progress as you work. **You should make at least one commit per function.**
4. When you've committed all of your work, there's nothing left to do to submit the assignment.

## Assignment

You will implement a linked list data structure in this assignment. The linked list will consist of a `head` pointer and a tail pointer. The head pointer will point to a `Node` struct, which will hold a data void pointer as well as a pointer to the next node in the list. The `tail` pointer will point to the final node in the linked list. The `next` pointer on the tail will point to `NULL`.


```
  ┌─────────┐    ┌─────────┐   ┌─────────┐    ┌─────────┐
  │     head│--->│  void*  │-->│  void*  │--->│  void*  │---> NULL
  │         │    └─────────┘   └─────────┘    └─────────┘
  │     tail│--------------------------------------^
  └─────────┘
```


The `List` and `Node` structs are declared in `linkedlist.h`, along with a number of functions you will need to implement.

```c
// Initialize an empty list. The head and tail pointers should point to NULL.
void initList(List* list_pointer);

// Create Node struct containing a void pointer to an item, return pointer to the newly created Node struct
Node* createNode(void* item);

// Insert new Node at the end of the list, containing a void pointer to item. The next pointer on this Node
// points to NULL. On success return 0. On failure, return 1.
int insertAtTail(List* list_pointer, void* item);

// Insert a Node at the head of the list, containing a void pointer to item. The next pointer on the
// newly created node points to the previous head of the list. On success return 0. On failure, return 1.
int insertAtHead(List* list_pointer, void* item);

// Insert a Node at the specified index, containing a void pointer to item. If the index is greater than
// the length of the list, the program should crash. On success return 0. On failure, return 1.
int insertAtIndex(List* list_pointer, int index, void* item);

// Remove Node from the end of list and return the void pointer it contains. The preceeding Node should
// point to NULL after this operation. On failure return a NULL pointer.
void* removeTail(List* list_pointer);

// Remove Node from start of list and return return the void pointer it contains. The following Node should 
// be the new head of the list. On failure return a NULL pointer.
void* removeHead(List* list_pointer);

// Insert Node item at a specified index and return return the void pointer it contains. The Node at the specified
// index before this function is called should be the next Node following the newly inserted Node.
// On failure return a NULL pointer.
void* removeAtIndex(List* list_pointer, int index);

// Return the pointer stored in the Node at the specified index. On failure return a NULL pointer. 
void* itemAtIndex(List* list_pointer, int index);
```

There is a print function that is already implemented for you. This will help you inspect the list as you write the above functions.

## Build Instructions

Write build instructions here. Explain to the user all the steps necessary to build this project including:

- What software (including versions) are needed?
- What system architectures and operating systems are supported?
- What commands need to be entered to build the project?

1. The user will need a compiler such as GCC (Ubuntu 7.5.0-3ubuntu1~18.04), they will need root/sudo permission to use terminal to access bash. The user will also need to have a current github repository with the link copied to clone it. Finally you will need a file explorer and enough file space for the repository. 
2. The user will need a modern operating system with 32 or 64 bit based operating system, perferably with Ubunut or some linux based processing system embedded if necessary. 
3. Once the terminal is opened with root permission do the following:
```bash
  $>cd to/the/right/folder/with/your/repository
  $>bash
  $>make
  $>cd build/bin
  $>./main
```

## Usage

Write usage instructions here. Explain to the user how they can integrate your library into their project. Usage instructions might include:

- What the user should `#include` into their project and where.
- An example command of how the user might build their project to link to your library.
- How to create a linked list using your library.
- How to use the linked list.
- How to clean up the linked list to avoid leaking memory.

1. 
```c
  #include <stdio.h>
  #include <stdlib.h>
  #include "linkedlist.h"
  //Include those in your lib.c and your main.c
```
2. 
```MAKEFILE
  gcc src/lib.c -c -I include
```
3. 
```c
  List *lp;
  lp = (List *) malloc(sizeof(List));
	initList(lp);
```
4. 
```c
  // Initialize an empty list
  void initList(List* list_pointer);

  // Create node containing item, return reference of it.
  Node* createNode(void* item);

  // Insert new item at the end of list.
  int insertAtTail(List* list_pointer, void* item);

  // Insert item at start of the list.
  int insertAtHead(List* list_pointer, void* item);

  // Insert item at a specified index.
  int insertAtIndex(List* list_pointer, int index, void* item);

  // Remove item from the end of list and return a reference to it
  void* removeTail(List* list_pointer);

  // Remove item from start of list and return a reference to it
  void* removeHead(List* list_pointer);

  // Insert item at a specified index and return a reference to it
  void* removeAtIndex(List* list_pointer, int index);

  // Return item at index
  void* itemAtIndex(List* list_pointer, int index);

  // Print List
  void printList(List* list_pointer);
```
5. To clean up your memory, make sure to `free(pointer)` whenever the pointer is not longer used to remove allocated memory for the pointer that was stored on heap.

## Examples

Write two examples demonstrating how to use your linked list library. These example should be complete in the sense that the user can just copy and paste them into their code and everything should work as long as they follow the build and usage instructions you gave them.

1. 
```c
  //to initilize the linked list, once you have included all your libraries and such (including the typedef structures)
  //move into the main.c file and do the following to initilze it
  int main() {
    List *name;
    name = (List *)malloc(sizeof(List));
    initlist(name);
  }
```
2. 
```c
  //since the pointer type and return types for most of the functions are void or convertable
  //feel free to use different data types
  char x= 'x';
  insertAtHead(name, &x);
  char y= 'y';
  insertAtHead(name, &y);
  char z= 'z';
  insertAtTail(name, &z);
  char t= '1';
  insertAtIndex(name, &t, 2);
  printList(lp);
```
