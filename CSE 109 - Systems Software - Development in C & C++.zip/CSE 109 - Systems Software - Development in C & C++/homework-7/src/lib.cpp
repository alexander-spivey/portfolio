#include <vector>
#include <stdio.h>
#include "pack109.hpp"

void pack109::printVec(vec &bytes)
{
  printf("[ ");
  for (int i = 0; i < bytes.size(); i++)
  {
    printf("%x ", bytes[i]);
  }
  printf("]\n");
}

//boolean

vec pack109::serialize(bool item)
{
  vec bytes;
  if (item == true)
  {
    bytes.push_back(PACK109_TRUE);
  }
  else
  {
    bytes.push_back(PACK109_FALSE);
  }
  return bytes;
}

bool pack109::deserialize_bool(vec bytes)
{
  if (bytes.size() < 1)
  {
    throw;
  }

  if (bytes[0] == PACK109_TRUE)
  {
    return true;
  }
  else if (bytes[0] == PACK109_FALSE)
  {
    return false;
  }
  else
  {
    throw;
  }
}

// integers
//8 bit
vec pack109::serialize(u8 item)
{
  vec bytes;
  bytes.push_back(PACK109_U8);
  bytes.push_back(item);
  return bytes;
}

u8 pack109::deserialize_u8(vec bytes)
{
  if (bytes.size() < 2)
  {
    throw;
  }
  if (bytes[0] == PACK109_U8)
  {
    return bytes[1];
  }
  else
  {
    throw;
  }
}
//32bit
vec pack109::serialize(u32 item)
{
  char buffer[4];
  vec bytes;
  buffer[0] = (item & 0xff000000) >> 24;
  buffer[1] = (item & 0x00ff0000) >> 16;
  buffer[2] = (item & 0x0000ff00) >> 8;
  buffer[3] = (item & 0x000000ff);
  bytes.push_back(PACK109_U32);
  bytes.push_back(buffer[0]);
  bytes.push_back(buffer[1]);
  bytes.push_back(buffer[2]);
  bytes.push_back(buffer[3]);
  return bytes;
}

u32 pack109::deserialize_u32(vec bytes)
{
  if (bytes.size() < 5)
  {
    throw;
  }
  if (bytes[0] == PACK109_U32)
  {
    u32 container = 0;
    u32 temp = bytes[4];
    container = container | temp;
    temp = bytes[3];
    container = container | temp << 8;
    temp = bytes[2];
    container = container | temp << 16;
    temp = bytes[1];
    container = container | temp << 24;
    return container;
  }
  else
  {
    throw;
  }
}
//64bit
vec pack109::serialize(u64 item)
{
  char buffer[8];
  vec bytes;
  buffer[0] = (item & 0xff00000000000000) >> 56;
  buffer[1] = (item & 0x00ff000000000000) >> 48;
  buffer[2] = (item & 0x0000ff0000000000) >> 40;
  buffer[3] = (item & 0x000000ff00000000) >> 32;
  buffer[4] = (item & 0x00000000ff000000) >> 24;
  buffer[5] = (item & 0x0000000000ff0000) >> 16;
  buffer[6] = (item & 0x000000000000ff00) >> 8;
  buffer[7] = (item & 0x00000000000000ff);
  bytes.push_back(PACK109_U64);
  bytes.push_back(buffer[0]);
  bytes.push_back(buffer[1]);
  bytes.push_back(buffer[2]);
  bytes.push_back(buffer[3]);
  bytes.push_back(buffer[4]);
  bytes.push_back(buffer[5]);
  bytes.push_back(buffer[6]);
  bytes.push_back(buffer[7]);
  return bytes;
}
u64 pack109::deserialize_u64(vec bytes)
{
  if (bytes.size() < 9)
  {
    throw;
  }
  if (bytes[0] == PACK109_U64)
  {
    u64 container = 0;
    u64 temp = bytes[8];
    container = container | temp;
    temp = bytes[7];
    container = container | temp << 8;
    temp = bytes[6];
    container = container | temp << 16;
    temp = bytes[5];
    container = container | temp << 24;
    temp = bytes[4];
    container = container | temp << 32;
    temp = bytes[3];
    container = container | temp << 40;
    temp = bytes[2];
    container = container | temp << 48;
    temp = bytes[1];
    container = container | temp << 56;
    return container;
  }
  else
  {
    throw;
  }
}
//i8
vec pack109::serialize(i8 item)
{
  vec bytes;
  bytes.push_back(PACK109_I8);
  bytes.push_back(item);
  return bytes;
}
i8 pack109::deserialize_i8(vec bytes)
{
  if (bytes.size() < 2)
  {
    throw;
  }
  if (bytes[0] == PACK109_I8)
  {
    return bytes[1];
  }
  else
  {
    throw;
  }
}
//i32
vec pack109::serialize(i32 item)
{
  char buffer[4];
  vec bytes;
  buffer[0] = (item & 0xff000000) >> 24;
  buffer[1] = (item & 0x00ff0000) >> 16;
  buffer[2] = (item & 0x0000ff00) >> 8;
  buffer[3] = (item & 0x000000ff);
  bytes.push_back(PACK109_I32);
  bytes.push_back(buffer[0]);
  bytes.push_back(buffer[1]);
  bytes.push_back(buffer[2]);
  bytes.push_back(buffer[3]);
  return bytes;
}
i32 pack109::deserialize_i32(vec bytes)
{
  if (bytes.size() < 5)
  {
    throw;
  }
  if (bytes[0] == PACK109_I32)
  {
    i32 container = 0;
    i32 temp = bytes[4];
    container = container | temp;
    temp = bytes[3];
    container = container | temp << 8;
    temp = bytes[2];
    container = container | temp << 16;
    temp = bytes[1];
    container = container | temp << 24;
    return container;
  }
  else
  {
    throw;
  }
}
//i64
vec pack109::serialize(i64 item)
{
  char buffer[8];
  vec bytes;
  buffer[0] = (item & 0xff00000000000000) >> 56;
  buffer[1] = (item & 0x00ff000000000000) >> 48;
  buffer[2] = (item & 0x0000ff0000000000) >> 40;
  buffer[3] = (item & 0x000000ff00000000) >> 32;
  buffer[4] = (item & 0x00000000ff000000) >> 24;
  buffer[5] = (item & 0x0000000000ff0000) >> 16;
  buffer[6] = (item & 0x000000000000ff00) >> 8;
  buffer[7] = (item & 0x00000000000000ff);
  bytes.push_back(PACK109_U64);
  bytes.push_back(buffer[0]);
  bytes.push_back(buffer[1]);
  bytes.push_back(buffer[2]);
  bytes.push_back(buffer[3]);
  bytes.push_back(buffer[4]);
  bytes.push_back(buffer[5]);
  bytes.push_back(buffer[6]);
  bytes.push_back(buffer[7]);
  return bytes;
}
i64 pack109::deserialize_i64(vec bytes)
{
  if (bytes.size() < 9)
  {
    throw;
  }
  if (bytes[0] == PACK109_U64)
  {
    i64 container = 0;
    i64 temp = bytes[8];
    container = container | temp;
    temp = bytes[7];
    container = container | temp << 8;
    temp = bytes[6];
    container = container | temp << 16;
    temp = bytes[5];
    container = container | temp << 24;
    temp = bytes[4];
    container = container | temp << 32;
    temp = bytes[3];
    container = container | temp << 40;
    temp = bytes[2];
    container = container | temp << 48;
    temp = bytes[1];
    container = container | temp << 56;
    return container;
  }
  else
  {
    throw;
  }
}

//Floats
//f32
vec pack109::serialize(f32 item)
{
  unsigned int *casted_num_pointer = (unsigned int *)&item;
  vec bytes = serialize(*casted_num_pointer);
  bytes[0] = PACK109_F32;
  return bytes;
}
f32 pack109::deserialize_f32(vec bytes)
{
  bytes[0] = PACK109_U32;
  u32 temp = deserialize_u32(bytes);
  f32 result = *(float *)&temp;
  return result;
}
//f64
vec pack109::serialize(f64 item)
{
  unsigned long *casted_num_pointer = (unsigned long *)&item;
  vec bytes = serialize(*casted_num_pointer);
  bytes[0] = PACK109_F64;
  return bytes;
}
f64 pack109::deserialize_f64(vec bytes)
{
  bytes[0] = PACK109_U64;
  u64 temp = deserialize_u64(bytes);
  f64 result = *(double *)&temp;
  return result;
}

//Strings
vec pack109::serialize(string item)
{
  vec bytes;
  int size = item.length();
  char s[size];
  if (size == 4)
  {
    bytes.push_back(PACK109_S8);
    bytes.push_back(size);
  }
  else
  {
    bytes.push_back(PACK109_S16);
    bytes.push_back(size);
  }
  for (int i = 0; i < size; i++)
  {
    s[i] = item[i];
    bytes.push_back(s[i]);
  }

  return bytes;
}

string pack109::deserialize_string(vec bytes)
{
  if (bytes.size() < 2)
  {
    throw;
  }
  if (bytes[0] == PACK109_S8 || bytes[0] == PACK109_S16)
  {
    string result = "";
    for (int i = 2; i < bytes.size(); i++)
    {
      result += bytes[i];
    }
    return result;
  }
  else
  {
    throw;
  }
}

//Arrays
//u8
vec pack109::serialize(std::vector<u8> item)
{
  vec bytes;
  bytes.push_back(PACK109_A8);  //array
  bytes.push_back(item.size()); //number of items
  bytes.push_back(PACK109_U8);  //array type
  for (int i = 0; i < item.size(); i++)
  {
    bytes.push_back(item[i]); //items
  }
  return bytes;
}
//u64
vec pack109::serialize(std::vector<u64> item)
{
  vec bytes;
  bytes.push_back(PACK109_A8);  //array
  bytes.push_back(item.size()); //number of items
  for (int i = 0; i < item.size(); i++)
  {
    char buffer[8];
    buffer[0] = (item[i] & 0xff00000000000000) >> 56;
    buffer[1] = (item[i] & 0x00ff000000000000) >> 48;
    buffer[2] = (item[i] & 0x0000ff0000000000) >> 40;
    buffer[3] = (item[i] & 0x000000ff00000000) >> 32;
    buffer[4] = (item[i] & 0x00000000ff000000) >> 24;
    buffer[5] = (item[i] & 0x0000000000ff0000) >> 16;
    buffer[6] = (item[i] & 0x000000000000ff00) >> 8;
    buffer[7] = (item[i] & 0x00000000000000ff);
    bytes.push_back(PACK109_U64);
    bytes.push_back(buffer[0]);
    bytes.push_back(buffer[1]);
    bytes.push_back(buffer[2]);
    bytes.push_back(buffer[3]);
    bytes.push_back(buffer[4]);
    bytes.push_back(buffer[5]);
    bytes.push_back(buffer[6]);
    bytes.push_back(buffer[7]);
  }
  return bytes;
}
//f64
vec pack109::serialize(std::vector<f64> item)
{
  vec bytes;
  bytes.push_back(PACK109_A8);  //array
  bytes.push_back(item.size()); //number of items
  int counter = 2;
  for (int i = 0; i < item.size(); i++)
  {
    unsigned long *casted_num_pointer = (unsigned long *)&item[i];
    vec temp = serialize(*casted_num_pointer);
    bytes.push_back(PACK109_F64);
    //printf("%d \n", temp.size());
    for (int i = 1; i < temp.size(); i++)
    {
      bytes.push_back(temp[i]);
    }
  }
  return bytes;
}
//string
vec pack109::serialize(std::vector<string> item)
{
  vec bytes;
  bytes.push_back(PACK109_A16);
  bytes.push_back(item.size());
  int size = item.size();
  char s[size];
  for (int i = 0; i < item.size(); i++)
  {
    if (size == 4)
    {
      bytes.push_back(PACK109_S8);
      bytes.push_back(item[i].length());
    }
    else
    {
      bytes.push_back(PACK109_S16);
      bytes.push_back(item[i].length());
    }
    for (int j = 0; j < item[i].length(); j++)
    {
      s[i] = item[i][j];
      bytes.push_back(s[i]);
    }
  }
  return bytes;
}

/*struct Person ann = { age: 10, height: 3.4, name: "Ann" };*/
vec pack109::serialize(struct Person item){
  vec bytes;
  bytes.push_back(PACK109_M8);
  bytes.push_back(PACK109_U8);
  bytes.push_back(item.age);
  bytes.push_back(PACK109_F32);
  bytes.push_back(item.height);
  //bytes.push_back(item.name);
  return bytes;
}