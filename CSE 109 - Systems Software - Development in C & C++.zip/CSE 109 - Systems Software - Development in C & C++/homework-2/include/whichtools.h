#include <stdbool.h>

bool file_exists(char *filename, int a);
