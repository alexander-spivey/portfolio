#include <sys/types.h>
#include <dirent.h>
#include <libgen.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

bool file_exists(char *filename, int a)
{   //Seperates into multiple paths
    //printf("START OF FUNCTION CALL \n");
    char *path = "PATH";
    char *result;
    result = getenv(path);
    //printf("PATH : %s\n", getenv("PATH"));

    const char delim[2] = ":";
    char *token; //orginal TOKEN
    token = strtok(result, delim);
    //strcpy(token2, result); //NEED TO FIGURE HOW TO COPY!!!
    //strcpy(token2, "GAY");
    int count = 0;
    int counter = 0;

    while (token != NULL)
    {
        //printf("%s\n", token);
        char* merged =NULL;
        merged = strdup(token);
        strcat(merged, "/");
        char* filenamedup = NULL;
        filenamedup = strdup(filename);
        strcat(merged, filenamedup);
        //printf("%s \n", merged);
        int result = access(merged, X_OK);
        if(result == 0) {
            printf("%s \n", merged);
            counter++;
            if(a==0){
                break;
            }
        }
        token = strtok(NULL, delim);
    }

    char *result2;
    result2 = getenv(path);
    token = result2;

     for (int i = 0; i < count; ++i) {
        token += strlen(token) + 1;  // get the next token by skipping past the '\0'
        token += strspn(token, ","); //   then skipping any starting delimiters
    }

    //printf("END OF FUNCTION CALL \n");
    if(counter > 0) {
        return true;
    } else {
        return false;
    }
    return 0;
}