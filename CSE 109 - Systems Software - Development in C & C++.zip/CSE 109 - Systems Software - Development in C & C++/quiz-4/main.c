#include <stdlib.h>
#include <stdio.h>

double* multiplyByThree(double input) {
  //double thrice = input * 3.0;
  double* thrice = malloc(sizeof(double));
  *thrice = input * 3.0;
  return thrice;
}

int main() {
  int* age = malloc(sizeof(int));
  *age = 30;
  double* salary = malloc(sizeof(double));
  *salary = 12345.67;

  // *myList + 1 = 2  ===>  myList[1]
  double* myList = malloc(sizeof(double)*3);
  myList[0] = 1.2; //v1
  *(myList + 1) = 2.3; //v2
  myList[2] = 3.4; //v1

  double* mtby3result = malloc(sizeof(double));
  mtby3result = multiplyByThree(*salary);

  printf("3x your salary is %.3f\n", *mtby3result);


  return 0;
}