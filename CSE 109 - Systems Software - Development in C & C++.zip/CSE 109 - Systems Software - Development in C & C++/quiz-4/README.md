# CSE 109 - Quiz 4

**Due: 3/2/2021 End of Day**

Make at least one commit per question. You can write your answers in this file, `README.md`. You can use the Gitlab interface to edit this file if you prefer.

## Question 1

How do you allocate variables to the stack?
`You declare the variable as you typically do: int var = 5;`
How do you allocate variables to the heap?
`You declare the varible as a pointer and use the function malloc to grab the information and store it to pointer.`

## Question 2

What are the pros and cons of stack allocated memory?
`Pros: Done for you, faster to access`
`Cons: Very not dynamic, smaller, and fixed`
What are the pros and cons of heap allocated memory?
`Pros: More storage, easily add and delete, and allocate things dynamically`
`Cons: Slower, need to follow the pointer to find stuff, more code`

## Question 3

Consider the following C program. The variables in this program are all stack allocated. Modify this program so that all variables are heap allocated. Make sure to free all heap allocated memory before the program ends.

```c
#include <stdlib.h>
#include <stdio.h>

double* multiplyByThree(double input) {
  //double thrice = input * 3.0;
  double* thrice = malloc(sizeof(double));
  *thrice = input * 3.0;
  return thrice;
}

int main() {
  int* age = malloc(sizeof(int));
  *age = 30;
  double* salary = malloc(sizeof(double));
  *salary = 12345.67;

  // *myList + 1 = 2  ===>  myList[1]
  double* myList = malloc(sizeof(double)*3);
  myList[0] = 1.2; //v1
  *(myList + 1) = 2.3; //v2
  myList[2] = 3.4; //v1

  double* mtby3result = malloc(sizeof(double));
  mtby3result = multiplyByThree(*salary);

  printf("3x your salary is %.3f\n", *mtby3result);


  return 0;
}
```

