# CSE 109 - Quiz 7

**Due: 4/8/2021 End of Day**

Make at least one commit per question. You can write your answers in this file, `README.md`. You can use the Gitlab interface to edit this file if you prefer.

## Question 1

Name the following operators and describe what they do:


- `<<` - `left shift, adds 0 in and shift all da bits by an amount`
- `>>` - `right shift, adds 0 in and sgift all da bits by an amount`
- `|` - `bitwise or, if either are 1 then return 1 else return 0`
- `&` - `bitwise and, if both are either than return 1, else return 0`
- `^` - `bitwise xor, if only bit is 1, return 1, else return 0`
- `~` - `bitwise not: if 1 return 0, else return 1`


## Question 2

Evaluate the following expressions. Express all answers in hexadecimal. Note the below code is not specific to any language. `u32` denotes a 32 bit unsigned integer. `u8` denotes an 8 bit unsigned integer. The prefix `0b` denotes a binary literal (base 2). The prefix `0d` denotes a decimal literal (base 10). The prefix `0x` denotes a hexadecimal literal (base 16).

```rust
u32 a = 0xAB;
u8  b = 0xAB;
u8  c = 0b10110010;
u8  d = 0b11001011;
u32 e = 0d10;
u8  f = 0d20;
```

```rust
a >> 4 = 0x4
b >> 4 << 4 = 0xA0
c | d = 0xFB
c + d = 0x7D
c & d = 0x82
c ^ d = 0x79
~d = 0x34
e << 2 = 0x28
f >> 2 = 0x5
f << 4 = 0x40
```

## Question 3

Write an expression using binary operators and the variable `u32 x = 0xAB` to produce the number `u32 y = 0xAB2AC54`

```rust
u32 x = 0xAB
x << 20 = 0xAB00000
x | 0xFFFFF = 0xABFFFFF
x & 0xFF2AC54 = 0xAB2AC54
x = y
```


## Extra Credit

If you had trouble with HW6, no worries! You now have an opportunity to make up some extra points, up to 10% (Maximum of 100% for the assignment).

Write an implementation for the function `memcpy`, which copies the bytes of one pointer to another pointer.

```c
void* memcpy(void* destination, const void* source, size_t n) {
    char* destination = (char *)destination;
    char* source = (char *)source;
    int counter++;
    while(counter < n) {
        *destination++ = *source++;
        counter++;
    }
}

// Usage:
int x = 0x12345678;
int y = 0;
memcpy(&y,&x,4);

y == x // True;

```




