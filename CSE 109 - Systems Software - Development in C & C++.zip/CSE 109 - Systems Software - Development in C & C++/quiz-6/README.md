# CSE 109 - Quiz 6

**Due: 3/31/2021 End of Day**

Make at least one commit per question. You can write your answers in this file, `README.md`. You can use the Gitlab interface to edit this file if you prefer.

## Question 1

For this question you can use any tool you like to solve it. Excel and Matlab are good choices. You can use Java, C, C++ or any other language you like.

- Download the dictionary of English words located here: https://github.com/dwyl/english-words/blob/master/words_alpha.txt
- Write a prehash function that maps each letter of the word to its ASCII value, and sums up them up. For example, the word "symbol" maps to the numbers 115, 121, 109, 98, 111, 108; and sums to 662.
- Apply the prehash function to each word in the dictionaty.
- Make a histogram of the prehashes and include it below as a PNG or JPEG. You can render images in markdown with the following syntax: https://www.markdownguide.org/basic-syntax/#images or with an HTML `<img>` tag.

`I included the image as: `
    ![Histogram of Prehashes](Histogram of Prehashes.png)

## Question 2

Looking at the histogram, can you say whether or not the prehash function you wrote is a good one for a hash table? What makes it good or bad?

`The prehash function created is not the best. It is fairly spread out, however there are obvious areas where they stack too much ontop of one another. If we were to flatten the curve and better distrubute, it would be a good prehash`

## Question 3

Make a modification to the prehash function you wrote such that the value to which the character maps is dependant on its position in the word. For example, an "b" as the first character of the word could map to `98`, as the second character of the word 196 (`98*2`), as the third character of the word 294 (`98*3`), and so on. For example, the word "symbol" will prehash to `115*1 + 121*2 + 109*3 + 98*4 + 111*5 + 108*6 = 2279`. Recreate the histogram from Question 1 and include it below as a PNG or JPEG.

What has changed between the histograms? Is this new prehash function any more suitable for a hash table? Why or why not?

`Personally speaking, I think the prehash funciton is way worse. By having larger words, they create larger and larger numbers, but since there aren't that many, we are just given an almost unseeable graph.`
`However, the curve is flattened more, so it may work better for the hash, but overall visibility has decreased: `![Histogram of Prehashes w/ Exponential Gain](Histogram of Prehashes w Exponential Gain.png)
