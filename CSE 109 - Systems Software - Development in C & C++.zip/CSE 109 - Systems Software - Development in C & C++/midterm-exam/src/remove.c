#include <stdio.h>
#include <stdlib.h>
#include "libbst.h"


///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Searches the BST for a node with an `item` equivalent to `query`, and removes that node from the tree. Returns a pointer to the `item` if it is found in the tree, `NULL` if it's not. Updates the depth of the BST after each remove.
Node *removeItem(BST *bstree, void *query) //CITE: https://www.programiz.com/dsa/binary-search-tree
{
    if (bstree->tree_root != NULL) //stealing code from my find function
    {
        //printf("T1");
        Node *pointer;
        //printf("T2");
        pointer = (Node *)bstree->tree_root;
        //printf("T3");
        Node *foo = removeN(pointer, query);
        //printf("T4");
        return foo;
    }
}
Node *removeN(Node *pointer, void *query)
{
    if (pointer == NULL)
    {
        printf("NULL \n");
        return pointer;
    }
    else if (query < pointer->item)
    {
        //printf("%d \n", pointer->item);
        pointer->nodes[0] = removeN(pointer->nodes[0], query);
    }
    else if (query > pointer->item)
    {
        //printf("%d \n", pointer->item);
        pointer->nodes[1] = removeN(pointer->nodes[1], query);
    }
    else
    {
        //printf("FOUND: %d \n", pointer->item);
        if (pointer->nodes[0] == NULL)
        {
            Node *temp = pointer->nodes[1];
            free(pointer);
            return temp;
        }
        else if (pointer->nodes[1] == NULL)
        {
            Node *temp = pointer->nodes[0];
            free(pointer);
            return temp;
        }
        Node *foo = malloc(sizeof(Node));
        foo = minVal(pointer->nodes[1]);
        pointer->item = foo->item;
        pointer->nodes[1] = removeN(pointer->nodes[1], foo->item);
    }
    return pointer;
}
Node *minVal(Node *node)
{
    Node *pointer = malloc(sizeof(Node));
    pointer = node;
    while (pointer && pointer->nodes[0] != NULL)
    {
        pointer = pointer->nodes[0];
    }
    return pointer;
}
