#include <stdio.h>
#include <stdlib.h>
#include "libbst.h"

//Initializes the fields on the BST. Returns nothing.
void initBinaryTree(BST *bstree, int item_size)
{
    bstree->depth = 0;
    bstree->item_size = item_size;
    bstree->tree_root = NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// takes a `BST*` and prints the entire tree. This can be in any format that helps you visualize the tree.
void printBST(BST *bstree) //CITE: https://www.geeksforgeeks.org/print-binary-tree-2-dimensions/
{
    if (bstree->tree_root != NULL)
    {
        Node *pointer;
        pointer = (Node *)bstree->tree_root;
        print(pointer, 0);
    }
    else
    {
        printf("\t*If you are reading this statement, everything has been freed*\n");
        return;
    }
    printf("\n");
}

void print(Node *pointer, int depth)
{
    if (pointer != NULL)
    {
        print(pointer->nodes[0], depth + 1); //left
        for (int i = 0; i < depth; i++)
        {
            printf("\t");
        }
        printf("%d -> \n", pointer->item);
        print(pointer->nodes[1], depth + 1); //right
    }
    /*else
    {
        printf("NULL -> ");
        return;
    }*/
}

//////////////////////////////////////////////////////////////////////////////////////////////
// takes a ``BST*` and frees all the nodes and their items. It should not free the BST itself.
void freeNodes(BST *bstree, Node *current)
{
    if (current == NULL)
    { //if null nothing to free
        return;
    }
    else
    {
        freeNodes(bstree, current->nodes[0]);
        freeNodes(bstree, current->nodes[1]);
        free(current);
    }
    bstree->tree_root = NULL;
}