#include <stdio.h>
#include <stdlib.h>
#include "libbst.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Searches the BST for a node with an `item` equivalent to `query`. Returns a pointer to the `item` if it is found in the tree, `NULL` if it's not.
void *findItem(BST *bstree, void *query)//CITE: https://www.programiz.com/ & https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/
{
    printf("\tLooking currently for: %d \n", query);
    if (bstree->tree_root != NULL) //stealing code from my print to use recursive function
    {
        Node *pointer;
        pointer = (Node *)bstree->tree_root;
        Node *foo = find(pointer, query);
        //printf("\t Hoo in helper: %d \n", foo->item);
        return foo;
    }
}

//recusive for find
Node *find(Node *pointer, void *query)
{
    //printf("Trying to find item %d\n", query);
    Node *hoo = malloc(sizeof(Node));
    void *foo = pointer->item;
    //printf("Checking if foo != query\n");
    if ((foo != query))
    {
        // printf("Checking to see if foo (%d) < query (%d)\n", foo, query);
        if (foo > query)
        {
            //printf("T2");
            if (pointer->nodes[0] != NULL)
            {
                //printf("T3");
                return find(pointer->nodes[0], query);
                //printf("T4");
            }
            else
            {
                //printf("T5");
                return NULL;
            }
        }
        //printf("Checking to see if foo (%d) > query (%d)\n", foo, query);
        if (foo < query)
        {
            //printf("S2");
            if (pointer->nodes[1] != NULL)
            {
                //printf("S3");
                return find(pointer->nodes[1], query);
                //printf("S4");
            }
            else
            {
                //printf("S5");
                return NULL;
            }
        }
    }
    else if ((foo == query))
    {
        //printf("\t Equal %d -> %d \n", pointer->item);
        hoo = pointer;
        printf("\tFound result: %d \n", hoo->item);
    }
    //printf("\t Hoo in recurse: %d \n", hoo->item);
    return hoo;
}

/*void* item = pointer->item;
    if(item != query) {
        find(pointer->nodes[0], query);
        find(pointer->nodes[1], query);
    } else if (item == query) {
        return pointer;
    }*/