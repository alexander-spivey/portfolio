#include <stdio.h>
#include <stdlib.h>
#include "libbst.h"
//mb use the print statement traverser...
//------------------------------------------------------------------------------------------------------------------------------------------//
// takes a ``BST*` and rebalances it. Returns nothing.
void rebalanceTree(BST *bstree) //CITE: https://medium.com/swlh/how-do-we-get-a-balanced-binary-tree-a25e72a9cd58
{//what makes me so mad is i know how this is supposed to work. i traverse through bst and save every value to array. 
//i free everything from the current bst. i sort array, find middle spot and start inserting values from middle of array out. then tadaaaaaa, new array without actual returning one
    printf("\tWARNING: PLEASE READ COMMENTS \n");
    Node *pointer; //make poiunter
    pointer = (Node *)bstree->tree_root; //set pointer to root
    int SIZE = bstree->depth + 1;
    int foo[SIZE]; //create an array, IDK HOW AND IDK WHY, I LOOK AT EVERY PAGE. AM BAD
    //foo = rebal(bstree, pointer, 0); //idk whats wrong here, probably need to hard copy each value
    //resort(foo); //function is to resort foo into some standard
    freeNodes(bstree, bstree->tree_root); //free all nodes so we can rewrite the BST
    /* The rest of this will be psuedocode essentially
    if(SIZE % 2 == 0) { //if even
        int middle = SIZE/2;
    } else{ //if odd
        int middle = (SIZE+1)/2;
    }
    for(int i = middle; i > 0; i++) { //from the center out
        insertItem(bstree, foo[i]); //insert like so [<----center,a,b,c,d...];
    }
    for(int j = middle+1; i < SIZE; i++) { //from the center out
        insertItem(bstree, foo[i]); //insert like so [...,1,2,3,center,a->];
    }
    then tadaaa you should have a proper binary tree then!
    */
}
int* rebal(BST *bstree, Node *pointer, int counter) 
{//the point of this function is to be a recursive mofo that transcribes all nodes into an array and then I organize array and then like mf free and reinsert everything?
    int foo[bstree->depth + 1]; //create that array [I know its an int cast, just trying to get this work]
    if (pointer != NULL) //if pointer not null, write to array the info and then incr counter to keep track of stuff
    {
        foo[counter] = (int)pointer->item; //counter to do da insert
        printf("%d \n", pointer->item);
        counter++; //counter incr to mkae sure we aren;t overwriting previous values
    }
    if (pointer->nodes[0] != NULL) //if next node to left aint null
    {
        return rebal(bstree, pointer->nodes[0], counter); //do da recursive dance to the left
    }
    else if (pointer->nodes[1] != NULL) //if next node to righy aint null
    {
        return rebal(bstree, pointer->nodes[1], counter); //do da recursive dance to rhe right
    }
    return foo;
}
void resort(BST *bstree, int foo[]) { //CITE: https://www.geeksforgeeks.org/c-program-to-sort-an-array-in-ascending-order/ 
//I want to make it apparent, I know how to do this just in Java so I needed some help (surprising how similar)
    int i, j, min; //set up our min and indexes for our loop
    for(int i = 0; i < bstree->depth; i++) { //loop thorugh comparing i to every other value then goes to i+1 and compares every other one
        min = i; //set min to i
        for(j = i +1; j < bstree->depth; j++) { //looping through the rest of array
            if(foo[j] < foo[i]) { //if j is < i, then min should = j
                min = j;
            }
        }
        swap(&foo[min], &foo[i]); //swap
    }
}

void swap(int* x, int* y) //CITE: https://www.geeksforgeeks.org/c-program-to-sort-an-array-in-ascending-order/
{
    int temp = *x;
    *x = *y;
    *y = temp;
}
