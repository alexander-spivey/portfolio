#include <stdio.h>
#include <stdlib.h>
#include "libbst.h"

//create node
Node *newNode(void *item) //CITE: https://www.programiz.com/dsa/full-binary-tree & https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/
{
    Node *node = malloc(sizeof(Node));
    node->item = item;
    node->nodes = malloc(sizeof(Node *) * 2);
    node->nodes[0] = NULL; //Left
    node->nodes[1] = NULL; //Right
    return node;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Inserts the item at the appropriate place in the tree.
// Returns `0` on success and `1` on failure.
//Updates the depth on the tree after each insert.
int insertItem(BST *bstree, void *item)
{
    if (bstree->tree_root == NULL)
    { //if root hasn't been made
        Node *temp = newNode(item);
        //printf("Temp: %d \n", temp->item);
        bstree->tree_root = temp;
        return 0;
    }
    else
    { //if head is > than item (smaller/left side)
        Node *pointer;
        pointer = (Node *)bstree->tree_root;
        int result = insert(pointer, item);
        if (result == 0)
        {
            bstree->depth++;
            printf("\tThe item: %d was successfully inserted \n", item);
        }
        return result;
    }
    return 1;
}

int insert(Node *current, void *item)
{
    if (current->item > item)
    { //head is > than item (left side)
        //printf("Current data is less than item \n");
        if (current->nodes[0] == NULL)
        {
            //printf("2nd if in less than item \n");
            Node *temp = newNode(item);
            current->nodes[0] = temp;
            return 0;
        }
        return insert(current->nodes[0], item);
    }
    else if (current->item < item)
    { //head is < than item (right side)
        //printf("Current data is greater than item");
        if (current->nodes[1] == NULL)
        {
            Node *temp = newNode(item);
            current->nodes[1] = temp;
            return 0;
        }
        return insert(current->nodes[1], item);
    }
    return 1;
}


/*if(bstree->tree_root == NULL) { //if root hasn't been made
        Node* temp = createNode(item);
        bstree->tree_root = temp;
        if(bstree->tree_root->item == item) {\
            bstree->depth++;
            return 0; //success
        } else {
            return 1; //failure
        }
    } else { //if head is > than item (smaller/left side)*/