#include <stdio.h>
#include <stdlib.h>
//perfection
//Structure of node
typedef struct
{
	void *item;			 //Data
	struct Node **nodes; //2 nodes [L,R]
} Node;

//Strucutre of a binary search tree
typedef struct
{
	Node *tree_root; //pointer to root node
	int depth;		 //character to hold depth of tree
	int item_size;	 //size of each tiem storred in bytes (malloc)
} BST;

//Initializes the fields on the BST. Returns nothing.
void initBinaryTree(BST *bstree, int item_size); //DONE

// Inserts the item at the appropriate place in the tree. Returns `0` on success and `1` on failure. Updates the depth on the tree after each insert.
int insertItem(BST *bstree, void *item); //DONE

//Recursive method for the other damn code.
int insert(Node *current, void *item); //DONE

// Searches the BST for a node with an `item` equivalent to `query`. Returns a pointer to the `item` if it is found in the tree, `NULL` if it's not.
void *findItem(BST *bstree, void *query); //DONE

//Recursive for findItem
Node *find(Node *pointer, void *query); //DONE

// takes a ``BST*` and frees all the nodes and their items. It should not free the BST itself.
void freeNodes(BST *bstree, Node* current); //DONE

// takes a ``BST*` and rebalances it. Returns nothing.
void rebalanceTree(BST *bstree); 

// Searches the BST for a node with an `item` equivalent to `query`, and removes that node from the tree. Returns a pointer to the `item` if it is found in the tree, `NULL` if it's not. Updates the depth of the BST after each remove.
Node *removeItem(BST *bstree, void *query); //DONE

//recusion for remove
Node *removeN(Node *pointer, void *query); //DONE

//minval to determine who takes head 
Node *minVal(Node *node); //DONE

// takes a `BST*` and prints the entire tree. This can be in any format that helps you visualize the tree.
void printBST(BST *bstree); //DONE

//Recursive print method
void print(Node *pointer, int depth); //DONE

//recusrion to transfer node values into an array
int *rebal(BST *bstree, Node *pointer, int counter);

//resort ascending
void resort(BST *bstree, int foo[]); //done

//swap stuff
void swap(int* x, int* y); //done