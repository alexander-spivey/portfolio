#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <vector>
#include "pack109.hpp"
#include <fstream>
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string>

#define KEY 42;

using namespace std;

int main(int argc, char *argv[])
{
    /*Variable setup from hwk 8*/
    int sockfd, newsockfd, portno, read_size;
    socklen_t clilen;
    const int buffersize = 4096;
    unsigned char buffer[buffersize]; //store messgaes
    struct sockaddr_in serv_addr, cli_addr;
    int n;

    char *address;
    char *portnum;
    char *token;

    /* Set up socket, hwk 8 */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("ERROR opening socket");
        exit(1);
    }

    if (argc < 2)
    {
        perror("ERROR, NOT ENOUGH ARGUMENTS");
        return -1;
    }
    else
    {
        if (strcmp(argv[1], "--hostname") == 0) //make sure hostname is there
        {
            //Get info argv[2]
            token = strtok(argv[2], ":"); //toklenize at the :
            address = token;
            token = strtok(NULL, ":"); //continue tokenizing, code from Geeks for Geeks
            portno = atoi(token);      //token now holds port number, convert to integer
        }
        else
        {
            perror("ERROR, HOSTNAME CALL WAS NOT FOUND AT PROPER PLACE");
            return -1;
        }
    }

    /* Initialize socket structure, copied from hwk 8 */
    bzero((char *)&serv_addr, sizeof(serv_addr)); //erases data at serv_addr address by writing 0s
    serv_addr.sin_family = AF_INET;               //designate type of address that socket will comm with
    serv_addr.sin_port = htons(portno);           //sets the struct port to port in network byte order
    /*n = inet_pton(AF_INET, address, &serv_addr.sin_addr.s_addr);
    if (n < 0)
    {
        perror("ERROR CONVERTING IP");
        exit(1);
    }*/
    //serv_addr.sin_addr.s_addr = inet_addr(address);
    inet_pton(AF_INET, address, &(serv_addr.sin_addr.s_addr)); //set server address to address

    printf("Port: %d\n", portno);
    printf("Address: %s\n", address);

    /* Now bind the host address using bind() call, copied from hwk 8*/
    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("ERROR on binding");
        exit(1);
    }

    /* Now start listening for the clients, here process will wait for the incoming connection， copied from hwk8*/
    printf("Awaiting connection from client \n");
    listen(sockfd, 5);
    clilen = sizeof(cli_addr);

    /* Accept actual connection from the client, hwk 8 */
    newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
    if (newsockfd < 0)
    {
        perror("ERROR on accept");
        exit(1);
    }
    else
    {
        printf("Established connection with client \n");
    }

    //Printing client connection info, copied from https://gist.github.com/codehoose/020c6213f481aee76ea9b096acaddfaf
    char host[NI_MAXHOST];    // Client's remote name (ip)
    char service[NI_MAXSERV]; // port client is on

    bzero(host, NI_MAXHOST); //set both of these values to null
    bzero(service, NI_MAXSERV);

    if (getnameinfo((sockaddr *)&cli_addr, sizeof(clilen), host, NI_MAXHOST, service, NI_MAXSERV, 0) == 0)
    {
        printf("%s connected on port %d\n", host, service);
    }
    else
    {
        inet_ntop(AF_INET, &cli_addr.sin_addr, host, NI_MAXHOST);
        printf("%s connected on port %d\n", host, ntohs(cli_addr.sin_port));
    }

    // Close listening socket
    close(sockfd);
    /* If connection is established then start communicating, copied from hwk 8 */
    /*------------------------------------------------------------------------------------------------------------------------------*/
    bzero(buffer, buffersize);           //clears buffersize bytes out of buffer
    read(newsockfd, buffer, buffersize); //reads from fd to buffer up to buffersize times
    if (n < 0)
    {
        perror("ERROR reading from socket");
        exit(1);
    }
    else
    {
        printf("Reading message into buffer \n");
    }

    for (int i = 0; buffer[i] != '\0'; i++)
    {
        buffer[i] = buffer[i] ^ KEY;
        printf("%d, ", buffer[i]);
    }

    /* Write a response to the client */
    n = write(newsockfd, "I got your message", 18);
    if (n < 0)
    {
        perror("ERROR writing to socket");
        exit(1);
    }
    return 0;
}
