# CSE 109 - Homework 3

**Due Date: 2/24/2021 EOD**

## Instructions 

**Read thoroughly before starting your project:**

1. Fork this repository into your CSE109 project namespace. [Instructions](https://docs.gitlab.com/ee/workflow/forking_workflow.html#creating-a-fork)
2. Clone your newly forked repository onto your development machine. [Instructions](https://docs.gitlab.com/ee/gitlab-basics/start-using-git.html#clone-a-repository) 
3. As you are writing code you should commit patches along the way. *i.e.* don't just submit all your code in one big commit when you're all done. Commit your progress as you work. **You should make at least one commit per question.**
4. When you've committed all of your work, there's nothing left to do to submit the assignment.

## Assignment

Answer the following questions about pointers in C. Make at least one commit per question. Each question is worth 1 point for a total of 5 points for the assignment. This will be scaled to 100% for your HW grade.

### Question 1

For each problem, write the English interpretation of the given line of C code. In the provided table, give the state of the memory after the line of code is executed. You can assume each block of memory can hold up to 32 bits of memory, and that pointers are 32 bits wide. Also assume that memory is aligned to 32 bit blocks (i.e. if a variable is not large enough to fill an entire block, it still occupies the entire block). You can start your memory range at an arbitrary address for the purpose of this problem. Write the contents and memory address as a 32 bit big-endian hexadecimal number.

For instance:
```c
  // Example
  int foo = 10;
  // Interpretation: Declare an integer called foo with the value 10
  // Memory:
  //         ┌──────────┬──────────┬──────────┬──────────┐
  //    label│foo       │          │          │          │
  //         ├──────────┼──────────┼──────────┼──────────┤
  //  address│0xFFD586B0│          │          │          │
  //         ├──────────┼──────────┼──────────┼──────────┤
  // contents│0x0000000A│          │          │          │
  //         └──────────┴──────────┴──────────┴──────────┘
```

```c
int main() {
  // Problem 1
  char* a;
  // Interpretation: Declare an char cast for a variable called a
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │    a     │    b     │     c    │     d    │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF68│          │          │          │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │No val    │          │
  // └──────────┴──────────┴──────────┴──────────┘
  
  
  // Problem 2
  int* b; 
  // Interpretation: Declares an int cast for a variable called b
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │    a     │    b     │     c    │     d    │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF68│0xDE04DF70│          │          │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │No val    │No val    │          │          │
  // └──────────┴──────────┴──────────┴──────────┘

  // Problem 3
  int c = 1632;
  // Interpretation: Declare an interger called c with a value of 1632
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │    a     │    b     │     c    │     d    │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF68│0xDE04DF70│0xDE04DF64│          │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │No val    │No val    │0x00000660│          │
  // └──────────┴──────────┴──────────┴──────────┘

  // Problem 4
  char d = 96;
  // Interpretation: Declare an char called d with
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │    a     │    b     │     c    │     d    │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF68│0xDE04DF70│0xDE04DF64│0xDE04DF5F│
  // ├──────────┼──────────┼──────────┼──────────┤
  // │No val    │No val    │0x00000660│0x00000060│
  // └──────────┴──────────┴──────────┴──────────┘

  // Problem 5
  b = &c;
  // Interpretation: Declare that variable b is equal to the address of c
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │    a     │    b     │     c    │     d    │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF68│0xDE04DF70│0xDE04DF64│0xDE04DF5F│
  // ├──────────┼──────────┼──────────┼──────────┤
  // │No val    │0xDE04DF64│0x00000660│0x00000060│
  // └──────────┴──────────┴──────────┴──────────┘
  
  // Problem 6
  a = &d;
  // Interpretation: Declare that variable a is equal to the address of d
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │    a     │    b     │     c    │     d    │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF68│0xDE04DF70│0xDE04DF64│0xDE04DF5F│
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF5F│0xDE04DF64│0x00000660│0x00000060│
  // └──────────┴──────────┴──────────┴──────────┘

  // Problem 7
  *a = *b;
  // Interpretation: Takes the value of char A, and moves it to b's pointer
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │    a     │    b     │     c    │     d    │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xDE04DF68│0xDE04DF70│0xDE04DF64│0xDE04DF5F│
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0x64      │0xDE04DF64│0x00000660│0x00000060│ ????? I think ????
  // └──────────┴──────────┴──────────┴──────────┘
  return 0;
}
```

### Question 2

In a the space below, write a function with the signature `void multiply_ptrs(int* x, int* y, int* z);`.

This function returns nothing. The body of the fuction should multiply the contents of `x` and `y` and store the result in `z`. For example, you could use it like this:

```c
int z;
int x = 5;
int y = 6;
multiply_ptrs(&x,&y,&z);
// z should be 30 after the above line is executed.
```

```c
int main(int argc, char **argv)
{
    int z;
    int x = 5;
    int y = 6;
    multiply_ptrs(&x,&y,&z);
    return 0;
}

void multiply_ptrs(int* x, int* y, int* z) {
    z = x[0] * y[0];
    printf("Function print Z: %d \n", z);
}
```

Reproduce the above function in a file called `multiply_ptrs.c`, and include a `main()` function that demonstrates its usage.

### Question 3

Using pointer arithmatic and what you know about c-strings, implement the function `int strlen(char *str);` in the space below. This function takes a c-string and returns the number of characters in the string.

```c
int main(int argc, char **argv)
{
    char *str = "This is the string.";
    int result = strlen(str);
    printf("Result: %d \n", result);
    return 0;
}

int strlen(char *str)
{
    int x = 0;
    int i = 0;
    while(x == 0) {
        if(str[i] == NULL) {
            printf("Reps: %d \n", i);
            return i;
        }
        i++;
    }
}
```

Reproduce the above function in a file called `strlen.c`, and include a `main()` function that demonstrates its usage.

### Question 4

In Homework 2 we used the `char** argv` argument vector to modify the behavior of a program depending on how it's called. Let's say we have a program called `a.out`, and we call it as follows:

```bash
$ ./a.out one two three
```

Conceptually we know that a double pointer like `argv` can be thought of as a 2D table. But we also know that memory only has one dimension. So what exactly does `argv` look like in memory? How can we encode a 2D table in one dimension? In the space below, write a program that will print out the memory locations of the entire `argv` datastructure. *i.e.*:

```
argv
argv[0]
argv[1]
argv[2]
argv[3]
argv[0][0]
argv[0][1]
etc...
```

Start by considering specifically the example I gave above (you can hardcode numbers since you know the size of all the arguments), but then try to generalize it for any `argv`. Write your program below:

```c
int main(int argc, char **argv)
{
    for(int i = 0; i < argc; i++) {
        printf("Argumnent %d: %s\n", i, argv[i]);
        int j = strlenAlex(argv[i]);
        for(int k = 0; k < j; k++) {
            printf("\t %d: %c \n", k+1, argv[i][k]);
                //printf("%d: h \n", k+1);
            }
            //printf("\tPart %d: %s \n", k+1, argv[i][k]);
        }
    }

int strlenAlex(char *str)
{
    int x = 0;
    int i = 0;
    while(x == 0) {
        if(str[i] == NULL) {
            printf("# of Letters: %d\n", i);
            return i;
        }
        i++;
    }
}
```

Reproduce the above function in a file called `argv.c`.

Explain below in words how argv is laid out. Fill out a table in the style of Question 1 with actual memory addresses and values from one of your test runs. You'll probably need more columns, as the block size on your machine will be 1 byte instead of 4 as in Q1.

```
Argv is a pointer that can be used to move down the array of characters to find the arguments.
  // Memory:
  // ┌──────────┬──────────┬──────────┬──────────┐
  // │  ./argv  │   this   │    is    │   test   │
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xF3FC5868│0xF3FC5870│0xF3FC5878│0xF3FC5880│
  // ├──────────┼──────────┼──────────┼──────────┤
  // │0xF3FC5A97│0xF3FC5A9E│0xF3FC5AA3│0xF3FC5AA6│ once again?????
  // └──────────┴──────────┴──────────┴──────────┘

```

## Question 5

Write a `Makefile` with five directives:

1. multiply_ptrs - builds `multiply_ptrs.c` into an executable `multiply_ptrs`.
2. strlen - builds `strlen.c` into an executable `my_strlen`.
3. argv - builds `argv.c` into an executable `argv`.
4. all - builds `multiply_ptrs`, `my_strlen`, `argv`. This directive should move the binaries into `build/bin`.
5. clean - deletes `multiply_ptrs`, `my_strlen`, `argv`.

I know it seems like I made all my files at onece due to my commit history, I just created a seperate folder to write all the code needed
for this project yesterday and just spent a couple minutes moving and commiting the changes.