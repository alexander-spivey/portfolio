#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
/*### Question 2

In a the space below, write a function with the signature `void multiply_ptrs(int* x, int* y, int* z);`.

This function returns nothing. The body of the fuction should multiply the contents of `x` and `y` and store the result in `z`. For example, you could use it like this:

```c
int z;
int x = 5;
int y = 6;
multiply_ptrs(&x,&y,&z);
// z should be 30 after the above line is executed.*/
int main(int argc, char **argv)
{
    int z;
    int x = 5;
    int y = 6;
    multiply_ptrs(&x,&y,&z);
    return 0;
}

void multiply_ptrs(int* x, int* y, int* z) {
    z = x[0] * y[0];
    printf("Function print Z: %d \n", z);
}

