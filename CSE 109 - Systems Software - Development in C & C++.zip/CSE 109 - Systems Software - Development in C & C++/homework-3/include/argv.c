#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char **argv)
{
    for(int i = 0; i < argc; i++) {
        printf("Argumnent %d: %s\n", i, argv[i]);
        printf("\t%s - Address:%X\tContent:%X\n", argv[i], &argv[i], argv[i]);
        int j = strlenAlex(argv[i]);
        for(int k = 0; k < j; k++) {
            printf("\t %d: %c \n", k+1, argv[i][k]);
                //printf("%d: h \n", k+1);
            }
            //printf("\tPart %d: %s \n", k+1, argv[i][k]);
        }
    }

int strlenAlex(char *str)
{
    int x = 0;
    int i = 0;
    while(x == 0) {
        if(str[i] == NULL) {
            printf("# of Letters: %d\n", i);
            return i;
        }
        i++;
    }
}



