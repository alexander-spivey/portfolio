#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
/*### Question 3

Using pointer arithmatic and what you know about c-strings, implement the function `int strlen(char *str);` in the space below. 
This function takes a c-string and returns the number of characters in the string.

```c
int strlen(char* str) {
  // Implement me
}
```
Reproduce the above function in a file called `strlen.c`, and include a `main()` function that demonstrates its usage. */
int main(int argc, char **argv)
{
    char *str = "This is the string.";
    int result = strlen(str);
    printf("Result: %d \n", result);
    return 0;
}

int strlen(char *str)
{
    int x = 0;
    int i = 0;
    while(x == 0) {
        if(str[i] == NULL) {
            printf("Reps: %d \n", i);
            return i;
        }
        i++;
    }
}
