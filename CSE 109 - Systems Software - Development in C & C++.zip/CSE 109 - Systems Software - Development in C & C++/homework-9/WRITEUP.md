I added all my comments and command usage as comments in my code.
As for the psuedo code, I was given permission by Corey. 

"
Alexander Spivey  
Okay, I am going to do my best to rewrite as much of the code as I can - 6:57
Then I am going to explain every line of code so that demonstrates my understanding of the code - 6:57
Will that work? - 6:57
I think for sure I can get send working partially, and maybe the request call, but thats about it - 6:57 PM

Corey Montella:mortar_board:  7:19 PM
Yeah that will work
"

The client was constructed very awkwardly. I had to work over Zoom with Tyler Hagmann from one of the ER's public computers.
We based the client.cpp based of the hwk 8 client.
After going back through the homeworks and getting the necessary code for grabbign the argv and comparing the strings, it was easy going from there.
Once we figured out how to parse all the comands from start call, we just had to enter all the data into the struct file and send the data after serilzing it to fit the deserialize. After wards we encrypt it with the key and send it. 
To figure out what my code does and how it works, please read all the lines of comments I made explaining every step. 
To run the program, you need to have the following:
1. The user will need a compiler such as G++ (g++-7 (7.5.0-3ubuntu1~18.04)), they will need root/sudo permission to use terminal to access bash. The user will also need to have a current github repository with the link copied to clone it. Finally you will need a file explorer and enough file space for the repository. 
2. The user will need a modern operating system with 32 or 64 bit based operating system, perferably with Ubunut or some linux based processing system embedded if necessary. 
3. Once the terminal is opened with root permission do the following:
```bash
  $>cd to/the/right/folder/with/your/repository
  $>cd make
  $>./client --hostname localhost:8081 --send files/document.txt
  $>./client --hostname localhost:8081 --request document.txt
```