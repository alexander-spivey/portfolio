#include<stdio.h>

int main() {
  printf("This is a basic C program. Hello World!");
  return 0;
}