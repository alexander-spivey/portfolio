# CSE 109 - Quiz 3

**Due: 2/23/2021 End of Day**

Make at least one commit per question. You can write your answers in this file, `README.md`. You can use the Gitlab interface to edit this file if you prefer.

## Question 1

Describe the purpose and usage of the following operators:

~~~
* - It has 2 main functions; Tells operator to multiply something; Acts a pointer for a certain value type of a variable
& - Used to get the address of a variable
~~~

## Question 2

How are pointers and arrays equivalent in C?
    Pointers and arrays access the same memory. Pointers can be used to access an array. The array’s name is a pointer to the first variable in the array. 

## Question 3

What is the difference between the following lines of code:

~~~
*foo + 1: it references and calls foo while adding +1 to the last index value
*(foo + 1):calls and references the next point where foo is defined and callable 
foo[1]: calls and references the second index in the foo array
~~~

## Homework 2 Extra Credit

If you had trouble with HW2, no worries! You now have an opportunity to make up some extra points, up to 25% (Maximum of 100% for the assignment).

Answer the following question: what are the top 3 challenges you faced in completing HW2, and what is your plan for overcoming them for the future?

~~~
1. Not understanding the program as a whole
    Before even really starting to read the homework as a whole, I just tried to jump in at the very first step and try to carry on without any future planning
2. Not knowing what code to use and how
    This isn't always an easy one to fix, but by looking at all the information shared on slack, readings, lectures, documentations, and the convenience of Googling; I know I will be better preppared for future endeavors
3. Using makefiles
    After really trying out writing the makefile the first time, I have better understood the structure and commands to move and create the files. 
~~~



