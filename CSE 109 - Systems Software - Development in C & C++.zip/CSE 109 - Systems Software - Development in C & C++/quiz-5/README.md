# CSE 109 - Quiz 5

**Due: 3/9/2021 End of Day**

Make at least one commit per question. You can write your answers in this file, `README.md`. You can use the Gitlab interface to edit this file if you prefer.

## Question 1

What is the benefit of having multiple frontends to a compiler?
`
With having mulitple frontends allow the coder to write in different langauges with different syntaxs, but still be able to compile all the files together into one
exe without needing multiple backends to optimize the file output, due to the frontend reading the code and translating it to an middle language between the backend
`

## Question 2

What do we mean when we say that compiling a program's source code is just translating it from one language to another?
`
So the compiler takes our code and rereads over it(ignoring comments and other such) and rewrites it into this middle language. This middle language then is read
by the backend and used to write the output file at the end. (Has Stages and is Modular)
`
## Question 3

What happens during the preprocessing phase of the C compilation pipeline?
`
It looks at the code and adds the include-files and other compilation instrcutions (and macros) and then retranslates it to the middle langauge. Once it goes into 
the Parser, it's grammar will be checked and let us know if there any syntax errors.
`
