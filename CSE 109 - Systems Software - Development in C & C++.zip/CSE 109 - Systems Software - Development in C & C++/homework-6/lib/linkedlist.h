#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "llnode.h"

namespace linkedlist
{
    template <class T>
    class LinkedList
    {
    private:
        linkedlist::Node<T> *head;
        linkedlist::Node<T> *tail;

    public:
        size_t length;
        LinkedList();
        ~LinkedList();
        size_t insertAtTail(T item);
        size_t insertAtHead(T item);
        size_t insertAtIndex(size_t index, T item);
        T removeTail();
        T removeHead();
        T removeAtIndex(size_t index);
        void printList();
        T itemAtIndex(size_t index);
        size_t itemExists(T search);
    };

    template <class T>
    LinkedList<T>::LinkedList()
    {
        head = NULL;
        tail = NULL;
        length = 0;
    }

    template <class T>
    size_t LinkedList<T>::insertAtHead(T item)
    {
        Node<T> *temp = new Node<T>(item); //create new node with the item
        if (temp == NULL)
        { //if node is null return 1 for failre
            return 1;
        }
        temp->next = head; //we say that the temp node is now the head node
        head = temp;       //and we now add the temp to the list????
        length++;
        return 0; //return sucess
    }

    template <class T>
    size_t LinkedList<T>::insertAtTail(T item)
    {
        Node<T> *temp = new Node<T>(item); //create a new node with item
        if (temp == NULL)
        { //if node is null return 1 for failre
            return 1;
        }
        temp->next = NULL; //we set the next node after the temp to be null

        Node<T> *pointer;          //creating a pointer
        pointer = (Node<T>*)head; //TRAVERSING THE LIST

        while (pointer->next != NULL)
        { //while pointer still exists
            /*Node<T> *pointer2 = (Node<T>*)pointer->next;
            if(pointer2->next == NULL) {
                break;
            }*/
            pointer = pointer->next;
        }
        //we hit null, time to add temp
        pointer->next = temp; //set next of pointer to be temp
        tail = pointer->next; //set tail to be the pointer->next
        length++;
        return 0; //return sucess
    }

    template <class T>
    size_t LinkedList<T>::insertAtIndex(size_t index, T item)
    {
        Node<T> *temp = new Node<T>(item); //create a new node with item
        if (temp == NULL)
        { //if node is null return 1 for failre
            return 1;
        }
        Node<T> *pointer;          //creating a pointer
        pointer = (Node<T> *)head; //TRAVERSING THE LIST

        for (size_t c = 1; c < index; c++)
        { //move the pointer to da index
            pointer = pointer->next;
            if (pointer == NULL)
            { //if it null, means we passed stuff already
                return 1;
            }
        }
        temp->next = pointer->next; //place right immediatly after
        pointer->next = temp;
        return 0; //return sucess
    }
    template <class T>
    T LinkedList<T>::removeTail()
    {
        Node<T> *temp; //making our tempest boi
        if (head == NULL)
        { //no head equals nothign to delete or reasons to date
            return NULL;
        }
        else
        {                           //it do give head
            Node<T> *pointer;          //our lil pointer boi
            pointer = (Node<T> *)head; //setting our pointer to have the same use as our head;
            while (pointer->next != NULL)
            { //if pointer next is not null dont stop
                pointer = pointer->next;
            }                             //pointer is now on last actual node
            temp = pointer;               //set temp equal to the pointer(aka the last node)
            pointer = temp->next;         //set the last node as temp next (which is null)
            T itemreturned = temp->item; //doing this so we can free temp and use the int to return it
            free(pointer);
            free(temp);          //free my boi he did nothing wrong
            return itemreturned; //returned value that was removed :D
        }
    }

    template <class T>
    T LinkedList<T>::removeHead()
    {
        Node<T> *temp;
        if (head == NULL)
        { //if head doesn't even exist nothing to delete
            return NULL;
        }
        else
        {                                 //there is head to delete ;)
            temp = head;                  //setting temp to head
            head = temp->next;            //setting head to next temp (which is null cuz only the curent temp has item)
            T itemreturned = temp->item; //doing this so we can free temp and use the int to return it
            free(temp);                   //free my boi he did nothing wrong
            return itemreturned;          //returned value that was removed :D
        }
    }

    template <class T>
    T LinkedList<T>::removeAtIndex(size_t index)
    {
        Node<T> *temp; //making our tempest boi
        if (head == NULL)
        { //no head equals nothign to delete or reasons to date
            return NULL;
        }
        else
        {                           //it do give head
            Node<T> *pointer;          //our lil pointer boi
            pointer = (Node<T> *)head; //setting our pointer to have the same use as our head;
            for (size_t c = 0; c < index; c++)
            {                             //loop for right index (idk why sometimes 1 or 0 work better xD)
                pointer = pointer->next;  //move that thicc pointer over
            }                             //on the proper index now
            temp = pointer;               //set temp equal to the pointer(aka the last node)
            pointer = temp->next;         //set the last node as temp next (which is null)
            T itemreturned = temp->item; //doing this so we can free temp and use the int to return it
            free(pointer);
            free(temp);          //free my boi he did nothing wrong
            return itemreturned; //returned value that was removed :D
        }
    }

    template <class T>
    void LinkedList<T>::printList()
    {
        Node<T> *node;

        // Handle an empty node. Just print a message.
        if (head == NULL)
        {
            printf("Empty List\n\n");
            return;
        }

        // Start with the head. TRAVERSING THE LIST
        node = (Node<T> *)head;

        printf("List: \n\t");
        while (node != NULL)
        {
            printf("[ %x ]", node->item);

            // Move to the next node
            node = (Node<T> *)node->next;

            if (node != NULL)
            {
                printf("-->");
            }
        }
        printf("\n\n");
    }

    template <class T>
    T LinkedList<T>::itemAtIndex(size_t index)
    {
       Node<T>* pointer; //creating a pointer
	    pointer = (Node<T>*) head; //TRAVERSING THE LIST
 
        for(size_t c = 0; c < index; c++) { //move the pointer to da index
            pointer = pointer->next;
            if(pointer == NULL) { //if it null, means we passed stuff already
                return NULL;
            }
        }
	    return pointer->item;
    }

    template <class T>
    size_t LinkedList<T>::itemExists(T search)
    {
        Node<T> *node;
        // Handle an empty node
        if (head == NULL)
        {
            return -1; //failure
        }
        // Start with the head. TRAVERSING THE LIST
        node = (Node<T> *)head;
        int counter = 0;
        while (node != NULL)
        {
            if(node->item == search) {
                return counter; //success case
            }
            node = (Node<T> *)node->next;
            counter++;
        }
        return -1; //fail case
    }
}