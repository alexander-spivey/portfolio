#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

namespace linkedlist
{
  template <class T>
  class Node
  {
  public:
    T item;
    linkedlist::Node<T> *next;
    Node(T data);
    ~Node();
  };
  
  template <class T>
  Node<T>::Node(T data)
  {
    item = data;
    next = NULL;
  }
}


