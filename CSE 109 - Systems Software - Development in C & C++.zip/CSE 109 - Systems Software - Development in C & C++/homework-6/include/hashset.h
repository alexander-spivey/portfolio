#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "llnode.h"
#include "linkedlist.h"

using namespace linkedlist;
template <class T>
class HashSet
{
private:
    // The backbone of the hash set. This is an array of Linked List pointers.
    LinkedList<T> **array;

    // The number of buckets in the array
    int size;

    // Generate a prehash for an item with a given size
    unsigned long prehash(T item);

public:
    // Initialize an empty hash set, where size is the number of buckets in the array
    HashSet(size_t size);

    // Free all memory allocated by the hash set
    ~HashSet();

    // Hash an unsigned long into an index that fits into a hash set
    unsigned long hash(T item);

    // Insert item in the set. Return true if the item was inserted, false if it wasn't (i.e. it was already in the set)
    // Recalculate the load factor after each successful insert (round to nearest whole number).
    // If the load factor exceeds 70 after insert, resize the table to hold twice the number of buckets.
    bool insert(T item);

    // Remove an item from the set. Return true if it was removed, false if it wasn't (i.e. it wasn't in the set to begin with)
    bool remove(T item);

    // Return true if the item exists in the set, false otherwise
    bool contains(T item);

    // Resize the underlying table to the given size. Recalculate the load factor after resize
    void resize(size_t new_size);

    // Returns the number of items in the hash set
    size_t len();

    // Returns the number of buckets that can be filled before reallocating
    int capacity();

    // Print Table. You can do this in a way that helps you implement your hash set.
    void print();
};

template <class T>
HashSet<T>::HashSet(size_t size)
{
    this->size = size;
    this->array = (LinkedList<T> **)malloc(sizeof(LinkedList<T>) * size);
    for (unsigned long i = 0; i < size; i++)
    {
        this->array[i] = new LinkedList<T>();
    }
}

//Modify this prehash function to work with a template type T instead of a char*
template <class T>
unsigned long HashSet<T>::prehash(T item)
{
    char temp = item;
    unsigned char *str = (unsigned char *)malloc(sizeof(unsigned char) * 5);
    *str = temp;
    unsigned long h = 5381;
    int c;
    while (c = *str++)
    {
        h = ((h << 5) + h) + c;
    }
    return h;
}

// Hash an unsigned long into an index that fits into a hash set
template <class T>
unsigned long HashSet<T>::hash(T item)
{
    return (prehash(item) % size);
}

// Insert item in the set. Return true if the item was inserted, false if it wasn't (i.e. it was already in the set)
// Recalculate the load factor after each successful insert (round to nearest whole number).
// If the load factor exceeds 70 after insert, resize the table to hold twice the number of buckets.
template <class T>
bool HashSet<T>::insert(T item)
{
    int counter = 0;
    unsigned long index = hash(item);         //find hash of item
    LinkedList<T> *temp = this->array[index]; //create temporary list that is addressed to index list
    if(temp->itemExists(item) != -1) {
        return false;
    }
    int result = temp->insertAtHead(item);    //insert that whore at the tail
    if (result == 0)
    { //success, so recalculate load factors
        int cap = size - capacity();
        int less = size*0.7;
        if(cap >= less) {
            resize(size*2);
        }
        return true;
    } else {
        return false;
    }
}

// Remove an item from the set. Return true if it was removed, false if it wasn't (i.e. it wasn't in the set to begin with)
template <class T>
bool HashSet<T>::remove(T item)
{
    unsigned long index = hash(item);
    LinkedList<T> *temp = this->array[index];
    T result = temp->itemExists(item);
    if (result != -1)
    {
        T result2 = temp->removeAtIndex(result);
        if (result2 == item)
        {
            return true;
        }
        else
        {
            return false;
        }
    } else {
        return false;
    }
}

// Return true if the item exists in the set, false otherwise
template <class T>
bool HashSet<T>::contains(T item)
{
    unsigned long index = hash(item);
    LinkedList<T> *temp = this->array[index];
    int result = temp->itemExists(item);
    if (result != -1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Resize the underlying table to the given size. Recalculate the load factor after resize
template <class T>
void HashSet<T>::resize(size_t new_size)
{
    LinkedList<T> **temp = (LinkedList<T> **)malloc(sizeof(LinkedList<T>) * new_size);
    for (unsigned long i = 0; i < new_size; i++)
    {
        temp[i] = new LinkedList<T>();
    } //create a new temp array
    for(int i = 0; i < size; i++) {
        temp[i] = this->array[i];
    } //rewrite over the temp
    this->array = temp;
    size = new_size;
}

// Returns the number of items in the hash set
template <class T>
size_t HashSet<T>::len()
{
    int totalL = 0;
    for (int i = 0; i < this->size; i++)
    {
        if (this->array[i] != NULL)
        {
            totalL = totalL + this->array[i]->length;
        }
    }
    printf("Total Number of Items: %d \n", totalL);
    return totalL;
}

// Returns the number of buckets that can be filled before reallocating
template <class T>
int HashSet<T>::capacity()
{
    int counter = 0;
    for(int i = 0; i < size; i++) {
        LinkedList<T> *temp = this->array[i];
        if(temp->length != 0) {
            counter++; //increase if length of ll is not 0
        }
    }
    int result = size - counter;
    //printf("%d Buckets Empty", result);
    return result;
}

// Print Table. You can do this in a way that helps you implement your hash set.
template <class T>
void HashSet<T>::print()
{
    for (int i = 0; i < size; i++)
    {
        printf("Index: %d \n", i);
        LinkedList<T> *temp = this->array[i]; //create temporary list that is addressed to index list
        temp->printList();
    }
}

template <class T>
HashSet<T>::~HashSet()
{
    free(this->array);
}